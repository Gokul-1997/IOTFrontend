import { inject } from '@angular/core';
import { Routes, Router } from '@angular/router';
import { AuthService } from './core/services/auth.service';
import { authGuard } from './core/guards/auth.guard';
import { adminGuard } from './core/guards/admin.guard';
import { sntSuperGuard } from './core/guards/snt-super.guard';
import { companyAdminGuard, companyRolesGuard, companyUserGuard } from './core/guards/company-admin.guard';
import { permissionGuard, anyPermissionGuard } from './core/guards/permission.guard';

export const routes: Routes = [

  // PUBLIC ROUTES
  { path: 'login', loadComponent: () => import('./pages/auth/login.component').then(m => m.LoginComponent) },
  { path: 'forgot-password', loadComponent: () => import('./pages/forgot/forgot-password.component').then(m => m.ForgotPasswordComponent) },
  { path: 'reset-password/:token', loadComponent: () => import('./pages/forgot/reset-password.component').then(m => m.ResetPasswordComponent) },

  // PROTECTED ROUTES (WITH SIDEBAR)
  {
    path: '',
    loadComponent: () => import('./layout/main-layout/main-layout').then(m => m.MainLayoutComponent),
    canActivate: [authGuard],
    children: [

      /* Every page here is guarded by the key Manage Access grants for it.
         The nine Phase 2 dashboards each have their own (page:analytics-*);
         they all used to share page:dashboard, so none could be sold or
         revoked on its own. alarms, downtime and maintenance
         and programs had catalogue modules and menu entries but NO guard, so
         un-granting them hid the menu item and left the URL open. */
      { path: 'dashboard', canActivate: [permissionGuard('page:dashboard')], loadComponent: () => import('./pages/dashboard/dashboard.component').then(m => m.DashboardComponent) },
      { path: 'factory', canActivate: [permissionGuard('page:analytics-factory')], loadComponent: () => import('./pages/factory/factory.component').then(m => m.FactoryComponent) },
      { path: 'maintenance-dashboard', canActivate: [permissionGuard('page:analytics-maintenance')], loadComponent: () => import('./pages/maintenance-dashboard/maintenance-dashboard.component').then(m => m.MaintenanceDashboardComponent) },
      { path: 'preventive-maintenance', canActivate: [permissionGuard('page:analytics-preventive')], loadComponent: () => import('./pages/preventive-dashboard/preventive-dashboard.component').then(m => m.PreventiveDashboardComponent) },
      { path: 'periodic-maintenance', canActivate: [permissionGuard('page:analytics-periodic')], loadComponent: () => import('./pages/periodic-dashboard/periodic-dashboard.component').then(m => m.PeriodicDashboardComponent) },
      { path: 'alarm-report', canActivate: [permissionGuard('page:analytics-alarms')], loadComponent: () => import('./pages/alarm-dashboard/alarm-dashboard.component').then(m => m.AlarmDashboardComponent) },
      { path: 'downtime-analysis', canActivate: [permissionGuard('page:analytics-downtime')], loadComponent: () => import('./pages/downtime-dashboard/downtime-dashboard.component').then(m => m.DowntimeDashboardComponent) },
      { path: 'operator-performance', canActivate: [permissionGuard('page:analytics-operators')], loadComponent: () => import('./pages/operator-dashboard/operator-dashboard.component').then(m => m.OperatorDashboardComponent) },
      { path: 'oee-dashboard', canActivate: [permissionGuard('page:analytics-oee')], loadComponent: () => import('./pages/oee-dashboard/oee-dashboard.component').then(m => m.OeeDashboardComponent) },
      // Tariff & Limits: its own page (it sat at the foot of the Energy Dashboard)
      { path: 'energy-tariff', canActivate: [permissionGuard('page:analytics-energy:settings')], loadComponent: () => import('./pages/energy-tariff/energy-tariff.component').then(m => m.EnergyTariffComponent) },
      { path: 'energy-dashboard', canActivate: [permissionGuard('page:analytics-energy')], loadComponent: () => import('./pages/energy-dashboard/energy-dashboard.component').then(m => m.EnergyDashboardComponent) },
      { path: 'maintenance-report', canActivate: [permissionGuard('page:maintenance-report')], loadComponent: () => import('./pages/maintenance-report/maintenance-report.component').then(m => m.MaintenanceReportComponent) },
      { path: 'dashboard/live/:id', canActivate: [permissionGuard('page:dashboard:live')], loadComponent: () => import('./pages/dashboard/live/live.component').then(m => m.LiveComponent) },

      { path: 'component', canActivate: [permissionGuard('page:component')], loadComponent: () => import('./pages/component/component_list.component').then(m => m.ComponentList) },

      { path: 'machines', canActivate: [permissionGuard('page:machines')], loadComponent: () => import('./pages/machines/machines.component').then(m => m.MachinesComponent) },
      { path: 'machines/create', canActivate: [permissionGuard('page:machines')], loadComponent: () => import('./pages/machines/machine-form.component').then(m => m.MachineFormComponent) },

      { path: 'shifts', canActivate: [permissionGuard('page:shifts')], loadComponent: () => import('./pages/shifts/shifts.component').then(m => m.ShiftsComponent) },
      { path: 'shifts/create', canActivate: [permissionGuard('page:shifts')], loadComponent: () => import('./pages/shifts/shift-form.component').then(m => m.ShiftFormComponent) },

      { path: 'operators', canActivate: [permissionGuard('page:operators')], loadComponent: () => import('./pages/operators/operators.component').then(m => m.OperatorsComponent) },
      { path: 'operators/create', canActivate: [permissionGuard('page:operators')], loadComponent: () => import('./pages/operators/operator-form.component').then(m => m.OperatorFormComponent) },

      { path: 'assignments', canActivate: [permissionGuard('page:assignments')], loadComponent: () => import('./pages/assignments/assignment.component').then(m => m.AssignmentComponent) },
      { path: 'assignments/operator-shift', canActivate: [permissionGuard('page:assignments')], loadComponent: () => import('./pages/assignments/operator-shift.component').then(m => m.OperatorShiftComponent) },

      { path: 'machine-shifts', canActivate: [permissionGuard('page:machine-shifts')], loadComponent: () => import('./pages/machine-shifts/machine-shift.component').then(m => m.MachineShiftComponent) },

      { path: 'plants', canActivate: [permissionGuard('page:plants')], loadComponent: () => import('./pages/plants/plants.component').then(m => m.PlantsComponent) },
      { path: 'plants/create', canActivate: [permissionGuard('page:plants')], loadComponent: () => import('./pages/plants/plant-form.component').then(m => m.PlantFormComponent) },

      { path: 'lines', canActivate: [permissionGuard('page:lines')], loadComponent: () => import('./pages/lines/lines.component').then(m => m.LinesComponent) },

      { path: 'reports', canActivate: [anyPermissionGuard(['page:reports', 'page:oee-reports'])], loadComponent: () => import('./pages/reports/reports').then(m => m.Reports) },
      // One Reports page: the old OEE Reports address opens its tab there
      { path: 'oee-reports', pathMatch: 'full', redirectTo: () => inject(Router).createUrlTree(['/reports'], { queryParams: { tab: 'oee-records' } }) },
      { path: 'charts', canActivate: [permissionGuard('page:charts')], loadComponent: () => import('./pages/charts/charts').then(m => m.Charts) },
      { path: 'quality', canActivate: [permissionGuard('page:quality')], loadComponent: () => import('./pages/quality/quality').then(m => m.Quality) },
      { path: 'job', canActivate: [permissionGuard('page:job')], loadComponent: () => import('./pages/job/job-list.component').then(m => m.JobListComponent) },

      { path: 'programs', canActivate: [permissionGuard('page:programs')], loadComponent: () => import('./pages/programs/programs.component').then(m => m.ProgramsComponent) },

      { path: 'alarms', canActivate: [permissionGuard('page:alarms')], loadComponent: () => import('./pages/alarms/alarms.component').then(m => m.AlarmsComponent) },
      { path: 'downtime', canActivate: [permissionGuard('page:downtime')], loadComponent: () => import('./pages/downtime/downtime.component').then(m => m.DowntimeComponent) },
      { path: 'maintenance', canActivate: [permissionGuard('page:maintenance')], loadComponent: () => import('./pages/maintenance/maintenance.component').then(m => m.MaintenanceComponent) },
      { path: 'security/2fa', loadComponent: () => import('./pages/security/twofa-setup.component').then(m => m.TwofaSetupComponent) },

      /* Every authenticated user reaches these — no permission key, because
         "view my own profile" and "change my own theme" are not a page a
         role can be denied. */
      { path: 'profile',       loadComponent: () => import('./pages/profile/profile.component').then(m => m.ProfileComponent) },
      { path: 'settings',      canActivate: [companyUserGuard], loadComponent: () => import('./pages/settings/settings.component').then(m => m.SettingsComponent) },
      { path: 'notifications', canActivate: [companyUserGuard], loadComponent: () => import('./pages/notifications/notifications.component').then(m => m.NotificationsComponent) },

      // ADMIN ROUTES (SNT_SUPER / COMPANY_ADMIN / ADMIN)
      {
        path: 'admin',
        canActivate: [adminGuard],
        children: [
          { path: 'companies', canActivate: [sntSuperGuard], loadComponent: () => import('./pages/admin/company-management.component').then(m => m.CompanyManagementComponent) },
          { path: 'plans', canActivate: [sntSuperGuard], loadComponent: () => import('./pages/admin/plan-management.component').then(m => m.PlanManagementComponent) },
          { path: 'users', canActivate: [companyAdminGuard], loadComponent: () => import('./pages/admin/user-management.component').then(m => m.UserManagementComponent) },
          { path: 'roles', canActivate: [companyRolesGuard], loadComponent: () => import('./pages/admin/role-management.component').then(m => m.RoleManagementComponent) },
          { path: '', redirectTo: 'users', pathMatch: 'full' }
        ]
      },

      // NO ACCESS
      { path: 'no-access', loadComponent: () => import('./pages/no-access/no-access.component').then(m => m.NoAccessComponent) },

      // DEFAULT — the first page this person can open. It was always the
      // Live Dashboard, so any role without that page (Quality, Setter, HR)
      // opened the app on "Access Denied".
      { path: '', pathMatch: 'full', redirectTo: () => inject(AuthService).getFirstAccessibleRoute() }
    ]
  },

  // FALLBACK
  { path: '**', redirectTo: 'login' }
];
