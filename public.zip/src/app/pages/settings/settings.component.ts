import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ThemeService } from '../../core/services/theme.service';
import { NotificationService } from '../../core/services/notification.service';
import { AuthService } from '../../core/services/auth.service';

interface PrefRow { key: string; label: string; hint: string; pages?: string[]; }

/**
 * Application settings: theme and per-user notification preferences.
 *
 * Distinct from the company-wide alert_preferences (whether an alarm/
 * offline/low-OEE event creates a notification at all, set by an admin).
 * This is one person deciding which of the notifications that do exist
 * they want surfaced to them.
 */
@Component({
  selector: 'app-settings',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './settings.component.html',
  styles: [`
    .set-grid { display: grid; gap: 1rem; grid-template-columns: repeat(auto-fit, minmax(min(100%, 24rem), 1fr)); align-items: start; }
    .set-grid .mexa-card + .mexa-card { margin-top: 0; }
    .set-hint { margin: -.4rem 0 .5rem; }
    .set-text { min-width: 0; }
    .set-ok { font-size: .8rem; color: #15803d; }
    :host-context(.dark) .set-ok { color: #6fdba0; }
    .set-retry { background: none; border: 0; padding: 0; font: inherit; text-decoration: underline; color: inherit; cursor: pointer; }
  `]
})
export class SettingsComponent implements OnInit {

  readonly rows: PrefRow[] = [
    { key: 'notify_alarm',             label: 'Alarms',            hint: 'A machine goes into alarm',
      pages: ['page:alarms', 'page:analytics-alarms', 'page:dashboard'] },
    { key: 'notify_maintenance',       label: 'Maintenance',       hint: 'A ticket or scheduled service is due',
      pages: ['page:maintenance', 'page:analytics-maintenance', 'page:analytics-preventive', 'page:analytics-periodic', 'page:maintenance-report'] },
    { key: 'notify_ticket',            label: 'Tickets',           hint: 'A ticket you are involved in changes status',
      pages: ['page:maintenance'] },
    { key: 'notify_program_transfer',  label: 'Program transfer',  hint: 'A transfer needs your approval, or completes',
      pages: ['page:programs'] },
    { key: 'notify_system',            label: 'System',            hint: 'Account and platform announcements' }
  ];

  /* Only the notifications this person's role can receive. Every role saw
     all five — HR could switch Program transfer alerts on and off although
     nothing ever sent one to HR. The API sends alarms only to the same roles. */
  get visibleRows(): PrefRow[] {
    return this.rows.filter(r => !r.pages || r.pages.some(p => this.auth.hasPermission(p)));
  }

  prefs: Record<string, boolean> = {};
  loading = true;
  errorMsg = '';
  saving = false;
  saveNote = '';
  saveErr = '';

  constructor(
    public theme: ThemeService,
    private auth: AuthService,
    private notif: NotificationService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void { this.load(); }

  load(): void {
    this.loading = true;
    this.errorMsg = '';
    this.cdr.markForCheck();
    this.notif.getPreferences().subscribe({
      next: (res: any) => {
        this.prefs = res.data || {};
        this.loading = false;
        this.cdr.markForCheck();
      },
      error: (err: any) => {
        this.loading = false;
        this.errorMsg = err?.error?.message || 'Unable to load your preferences.';
        this.cdr.markForCheck();
      }
    });
  }

  toggle(key: string): void {
    this.prefs = { ...this.prefs, [key]: !this.prefs[key] };
    this.save();
  }

  /* An "Email digest" switch sat here. Nothing ever sent a digest, so it saved
     a choice that did nothing; it comes back with the digest itself, next
     phase. */

  /** Saves on every change — a settings toggle, not a form with a submit
   *  step, so there is nothing for the user to remember to click. */
  private save(): void {
    this.saving = true;
    this.saveErr = '';
    this.saveNote = '';
    this.cdr.markForCheck();

    this.notif.updatePreferences(this.prefs).subscribe({
      next: (res: any) => {
        this.saving = false;
        this.prefs = res.data || this.prefs;
        this.saveNote = 'Saved.';
        this.cdr.markForCheck();
      },
      error: (err: any) => {
        this.saving = false;
        this.saveErr = err?.error?.message || 'Could not save. Try again.';
        this.cdr.markForCheck();
      }
    });
  }
}
